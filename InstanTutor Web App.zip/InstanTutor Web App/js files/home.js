document.querySelector(".button").addEventListener("click", function () {
  window.location.href = "loginstudent.html";
});

document.querySelector(".button2").addEventListener("click", function () {
  window.location.href = "logintutor.html";
});
