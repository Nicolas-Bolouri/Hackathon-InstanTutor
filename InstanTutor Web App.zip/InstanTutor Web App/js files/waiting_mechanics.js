// Button
document.querySelector(".button").addEventListener("click", function () {
  window.location.href = "videochat_mechanics.html";
});
